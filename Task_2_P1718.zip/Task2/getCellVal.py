# -*- coding: utf-8 -*-
"""
**************************************************************************
*                  IMAGE PROCESSING (Prashikshan 2017)
*                  ================================
*  This software is intended to teach image processing concepts
*
*  MODULE: Task2C
*  Filename: getCellVal.py
*  Version: 1.0.0  
*  Date: May 3, 2017
*  
*  Author: Prashikshan Team.
**************************************************************************
"""
# detectCellVal detects the numbers/operatorsm,
# perform respective expression evaluation
# and stores them into the grid_map 
# detectCellVal(img,grid_map)

# Find the number/operators, perform the calculations and store the result into the grid_map
# Return the resultant grid_map
import cv2
import numpy as np
# comment here
def detectCellVal(img_rgb,grid_map):
    #your code here
    digit=np.zeros((12,96,96),dtype=np.uint8)
    temp=np.zeros((100,100),dtype=np.uint8)
    demo =cv2.cvtColor(img_rgb,cv2.COLOR_RGB2GRAY)
    for i in range(10):
        path="G:\Task2\Experiment\Task2C_FinalTask\digits\\"+str(i)+".jpg"
        temp=cv2.imread(path,cv2.IMREAD_GRAYSCALE)
        digit[i]=temp[2:98,2:98]
    temp=cv2.imread("G:\Task2\Experiment\Task2C_FinalTask\digits\minus.jpg",cv2.IMREAD_GRAYSCALE)
    digit[10]=temp[2:98,2:98]
    temp=cv2.imread("G:\Task2\Experiment\Task2C_FinalTask\digits\plus.jpg",cv2.IMREAD_GRAYSCALE)
    digit[11]=temp[2:98,2:98]
    def mse(imageA,imageB):
        err=np.sum((imageA.astype("float")-imageB.astype("float"))**2)
        err/=float(imageA.shape[0]**2)
        return err
    for i in range(6):
        for j in range(6):
            temp=demo[((i*100)+2):((i*100)+98),((j*100)+2):((j*100)+98)]
            for k in range(1,12):
                if (mse(digit[k],temp)<10):
                    grid_map[i][j]=k
                    if (k==11):
                        grid_map[i][j]='-'
                    if (k==12):
                        grid_map[i][j]='+'
    s=0
    for i in range(6):
        s+=grid_map[i][0]
        for j in range (2,6,2):
            if ((grid_map[i][j-1])=='+'):
                s=s+grid_map[i][j]
            if ((work_space[i][j-1])=='-'):
                s=s-grid_map[i][j] 
    
    return grid_map
